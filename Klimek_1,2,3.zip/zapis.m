function [] = zapis(tab)

%zapisywanie macierzy do Excela
xlswrite('points',tab);

end